function send(){
	window.alert("Pesanmu sudah terkirim...")
}

window.alert("Hai.. Selamat datang!")

